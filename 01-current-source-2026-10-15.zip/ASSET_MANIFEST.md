# A Special T Prototype Asset Manifest

The locally reviewable prototype uses the exact supplied brand marks, mascot, approved homepage-reference crops, and novelty artwork. These binary assets remain in the local `assets/` directory and are intentionally not regenerated or altered. This manifest records the source and SHA-256 checksums for recovery.

## Supplied Source Material

- Brand marks, mascot, homepage mockup, service-area visual, and novelty art: `/Users/brittanybruno/Documents/A Special T of the Palm Beaches, Inc./AST Website Build References/`
- `palm-beach-coast-hero-v1.png`: existing project-approved visual asset, used as the sunlit, out-of-focus coastal hero backdrop.
- `approved-*` assets: crops derived from the supplied `AST Custom Apparel Homepage Mockup.png` to preserve the approved visual direction.

## Current Asset Checksums

| Asset | SHA-256 |
| --- | --- |
| `approved-category-bags.png` | `ef36ecf6823e8df09a14b6ddef07ca5550470b6148c59ca5ef5b077f5e660ab7` |
| `approved-category-drinkware.png` | `360fabcebd879c50b1b806cfccaf667dfd63c666542da0fb62d65978b4fd9b90` |
| `approved-category-embroidery.png` | `1c227f4dd338d5295c0b257965cae0ed0a772fab8d3bcf7ee376f5e26b884dc4` |
| `approved-category-hats.png` | `17a064cb39b6bcaa3ec4f371df129fa7c550075205b42052239d9c03b370ed08` |
| `approved-category-pens.png` | `179af6d0f83ba550004da635152f01f5898220afef90dd525354b6a67b520f49` |
| `approved-category-tshirts.png` | `47cccdc37ca1ec382a5bc606f1b8eaa2ba084bf8fb0b4c81d48e4db8bed71eb1` |
| `approved-collection-bulk.png` | `f1d24b8b4eb7b921aa0f7c67e6f4a23786b4b9dc172731f17356b6b3acc19863` |
| `approved-hero-coastal-backdrop.png` | `6ce8559c227caf13c964c18539796cc488dc1b355141b53ea6b5aff26f54814b` |
| `approved-hero-shirt-stack.png` | `5b661496a56478d2847bbad6e79d0304462e4c3393ece08b72b3af507ba28b68` |
| `approved-panel-bulk-value.png` | `662efc8343bde930fbd8f6e07618feca3abbf0c72a37e64233f08d984fe98df1` |
| `approved-panel-business-essentials.png` | `cab06c3ce644f1305f67c0143b904869a403ab08050c879837134f70cbd6c50c` |
| `approved-panel-premium-impact.png` | `ef114ac5a99a49bbecead658ce9892d7f5cbbce27bd790a9f17baebbc32af588` |
| `approved-service-area.png` | `0c22a189e0477a97d9d704b2ea78e52fc6d5396f44728d4c9b68eccb7b177e98` |
| `logo-gator-sunset.png` | `a659a3f949032591c189dfa58b5103118e41904a4160973bf8dad8bad3c30850` |
| `logo-mark.png` | `8b6463fd05d243be626c095d6697dadd637a62e95af62c1e55d12c2db8bc53b5` |
| `logo-primary.png` | `caedfaf468c5ec7095ad084781bb5158cdb6a899ebb2555fb18dd0b615b74f0a` |
| `novelty-humidity.png` | `ebd4dabffd146425f37c645bfc93e011282cd9a81682b566d529927ebf3e3917` |
| `novelty-iguanas.png` | `064382cba0f857886749fdb43db901e2ae83bd5fb0d24947261f16f054a7c3d0` |
| `novelty-kids.png` | `8d27b3e60357eb83fb2b2221b6e0803d4ddac652b433a21850d29d31c13f3718` |
| `novelty-pool.png` | `d801e2ce04a32b37cf692546b1bfdb28e58383f3100aa917bfe1be107b73dfc3` |
| `palm-beach-coast-hero-v1.png` | `0755ab076ff4f60901800461e81b977a686eaf09325e9f245acf431e2d739349` |

The separate local backup is `backups/2026-10-14-before-reference-fidelity/`.
