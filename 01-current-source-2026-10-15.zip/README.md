# A Special T Homepage Prototype

## Open It Locally

From this folder, run:

```sh
python3 -m http.server 4174
```

Then open [http://localhost:4174](http://localhost:4174).

## What Is Included

- Responsive homepage with desktop and mobile layouts.
- Anchored navigation, mobile navigation, searchable prototype feedback, cart preview, and non-submitting quote form feedback.
- The supplied AST logos, alligator mascot, and four original novelty-tee art files copied into `assets/` for local use.
- Placeholder category cards and deliberately non-live quote/cart/search behavior.
- The hero shirt stack, featured panels, category thumbnails, and service-area treatment are local crops derived from the supplied approved homepage mockup; they are retained only to preserve the selected visual direction in this prototype.
- The hero uses the retained `palm-beach-coast-hero-v1.png` for the sunlit, out-of-focus coastal setting, the supplied mascot, and the approved stacked-shirt crop. The coral price guarantee and footer lockup use the supplied AST brand marks without redraws or substitutions.
- `ASSET_MANIFEST.md` records each approved visual asset and its checksum. The full local assets stay beside the source; the manifest makes the asset set recoverable if source files are copied to a text-only repository archive.
- A local Bulk T-Shirt Collection (`#collection`) and reusable quote-first product detail (`#product`) with color, size, quantity, decoration, placement, artwork-selection, and quote-feedback controls.

## Reference-Fidelity Backup

The pre-correction prototype is recoverable at `backups/2026-10-14-before-reference-fidelity/`. It contains the prior source files and its local `assets/` directory.

## Technical Choice

This first, local-only prototype uses a lightweight component-style HTML/CSS/JavaScript architecture rather than adding an application framework before there is a product-data or checkout integration to support. Reusable patterns include the header, navigation, buttons, category cards, feature cards, and footer. It can be migrated into a Shopify theme section set or a React/Next storefront once the catalog, product model, and Shopify integration plan are approved.

## Intentional Placeholders

- No product prices, inventory, supplier relationships, checkout, or payment processing.
- The cart, search, and form do not save or transmit information.
- Product selection controls are local interactions only. The artwork chooser neither uploads nor retains files, and cart functionality stays disabled until approved product pricing is provided.
- Category imagery supports visual review only; it does not represent confirmed sellable inventory.
- Phone and email links match the supplied visual reference and should be confirmed before a production launch.

## Targeted Revision Requests

Please identify the section and desired change, for example: “Make the hero mascot smaller on mobile,” “Use a different supplied novelty design,” or “Change the Business Essentials copy.”
