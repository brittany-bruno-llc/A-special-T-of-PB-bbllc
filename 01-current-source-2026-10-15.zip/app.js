const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.primary-nav');
const searchButton = document.querySelector('.search-toggle');
const searchRow = document.querySelector('.search-row');
const cartButton = document.querySelector('.cart-toggle');
const cartPanel = document.querySelector('.cart-panel');
const cartClose = document.querySelector('.cart-close');
const homeMain = document.querySelector('#home-main');
const collectionMain = document.querySelector('#collection-main');
const productMain = document.querySelector('#product-main');

menuButton.addEventListener('click', () => {
  const expanded = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!expanded));
  nav.classList.toggle('is-open', !expanded);
});

document.querySelectorAll('.primary-nav a').forEach((link) => link.addEventListener('click', () => {
  nav.classList.remove('is-open');
  menuButton.setAttribute('aria-expanded', 'false');
}));

searchButton.addEventListener('click', () => {
  const opening = searchRow.hidden;
  searchRow.hidden = !opening;
  searchButton.setAttribute('aria-expanded', String(opening));
  if (opening) document.querySelector('#search').focus();
});

document.querySelector('.search-submit').addEventListener('click', () => {
  const term = document.querySelector('#search').value.trim();
  document.querySelector('.search-result').textContent = term ? `“${term}” is ready for future catalog search.` : 'Enter a search term to preview catalog search.';
});

function setCart(open) {
  cartPanel.classList.toggle('is-open', open);
  cartPanel.setAttribute('aria-hidden', String(!open));
  cartButton.setAttribute('aria-expanded', String(open));
}
cartButton.addEventListener('click', () => setCart(!cartPanel.classList.contains('is-open')));
cartClose.addEventListener('click', () => setCart(false));

document.querySelector('.quote-form').addEventListener('submit', (event) => {
  event.preventDefault();
  document.querySelector('.form-message').textContent = 'Thanks—this prototype captured no data. Connect this form to your selected quote workflow when ready.';
});

function setShopView() {
  const route = window.location.hash;
  const showCollection = route === '#collection';
  const showProduct = route === '#product';
  homeMain.hidden = showCollection || showProduct;
  collectionMain.hidden = !showCollection;
  productMain.hidden = !showProduct;
  if (showCollection || showProduct) {
    window.scrollTo(0, 0);
    document.title = showProduct ? 'Everyday Team T-Shirt | A Special T' : 'Bulk T-Shirts | A Special T';
  } else {
    document.title = 'A Special T | Custom Apparel & Promotional Products';
  }
}

window.addEventListener('hashchange', setShopView);
setShopView();

document.querySelectorAll('[data-choice]').forEach((group) => {
  group.querySelectorAll('button').forEach((button) => button.addEventListener('click', () => {
    group.querySelectorAll('button').forEach((item) => item.classList.remove('is-selected'));
    button.classList.add('is-selected');
  }));
});

const quantity = document.querySelector('#quantity');
document.querySelectorAll('[data-qty]').forEach((button) => button.addEventListener('click', () => {
  const current = Number(quantity.textContent);
  quantity.textContent = Math.max(1, current + (button.dataset.qty === 'plus' ? 25 : -25));
}));

document.querySelector('#artwork-file').addEventListener('change', (event) => {
  const file = event.target.files[0];
  document.querySelector('#upload-status').textContent = file ? `${file.name} selected locally. It has not been uploaded or retained.` : 'No file selected. Files are not uploaded or retained in this prototype.';
});

document.querySelector('.quote-product').addEventListener('click', () => {
  document.querySelector('.product-feedback').textContent = `Quote request prepared for ${quantity.textContent} shirts. This local prototype does not send or save the request.`;
});
